
import post from './components/page/create.vue';
import index from './components/page/index.vue';
import edit from './components/page/edit.vue';
import list from './components/page/list.vue';
import show from './components/page/show';
import TodoAdd from './components/page/Todo/add';


export default {
    mode: 'history',
}
export const routes = [
    {
        name:   'tambah',
        path:   '/tambah',
        component: TodoAdd
    },
    {
        name:   'home',
        path:   '',
        component: index
    },
    {
        name: 'post',
        path: '/post',
        component: post
    },
    {
        name: '/',
        path: '/index',
        component: index
    },
    {
        name:   'edit',
        path:    '/edit/:id',
        component: edit
    },
    {
        name:   'show',
        path:   '/show/:id',
        component: show,
    },
    {
        name:   'list',
        path:   '/list',
        component: list
    },
];
