<template>
    <div class="container">
        <div class="pt-4"></div>
        <div class="row">
            <div class="col-md-6">
                <form @submit.prevent="create" method="post">
                <div class="form-group row my-2">
                    <label for="" class="col-form-label col-md-2">Nama</label>
                    <div class="col-md-8">
                        <input type="text" name="nama" v-model="hehe.nama" class="form-control">
                    </div>
                </div>
                <div class="form-group row my-2">
                    <label for="" class="col-form-label col-md-2">Judul</label>
                    <div class="col-md-8">
                        <input type="text" name="judul" v-model="hehe.judul" class="form-control">
                    </div>
                </div>
                <div class="form-group row my-2">
                    <label for="" class="col-form-label col-md-2">Deskripsi</label>
                    <div class="col-md-8">
                        <input type="text" name="deskripsi" v-model="hehe.deskripsi" class="form-control">
                    </div>
                </div>
                <div class="form-group row my-2">
                    <label for="" class="col-form-label col-md-2">Status</label>
                    <div class="col-md-8">
                        <input type="text" name="status" v-model="hehe.status" class="form-control">
                    </div>
                </div>
                <button type="submit" class="btn btn-info">Kirim</button>
            </form>
            </div>
    </div>
</div>
</template>
<script>
export default {
    data: function(){
        return {
            errors: [],
            hehe:   {},
            timeout:''
        }
    },
    methods:{
        create(){
            axios.post('http://127.0.0.1:8000/api/post/create',this.$data.hehe)
            .then(res => {
                this.data = res.data.msg
                    confirmbtn : alert(res.data.msg + 'berhasil di tambahkan')
                setTimeout(function() {
                    window.location.href = 'http://127.0.0.1:8000/index';
                },200);
                // object.onCick(), {
                //     this.$router.push('list')
                // }
            });
        },
    },
}
</script>