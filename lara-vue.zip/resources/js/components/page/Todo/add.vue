<template>
    <div id="app">
        <div class="pt-4"></div>
        <div class="container">
        <div class="row">
            <div class="card col-md-8">
                <div class="card-title">a</div>
            </div>
        </div>
        </div>
    </div>
</template>
<script>
export default {
    
}
</script>