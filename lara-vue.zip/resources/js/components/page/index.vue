<template>
<div class="app">
    <div class="container">
        <div class="pt-4"></div>
          <div class="row">
            <div class="card col-md-8">
              <div class="" v-if="(Todo, index) < 0">
              <div class="table-responsive">
                <table class="table table-bordered">
                  <thead align="center" class="my-2">
                    <th>No.</th>
                    <th>ToDo List</th>
                    <th>Status</th>
                    <th>Publish Date</th>
                    <th>Option</th>
                  </thead>
                  <tbody>
                    <tr v-for="(data, index) in Todo" :key="data.id">
                      <td>{{index+1}}</td>
                      <td>{{ data.text }}</td>
                      <td>{{ data.status == 1?'Aktif':'Tidak Aktif'  }}</td>
                      <td>  </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              </div>
              <div class="" v-else>
                <p align="center" class="my-4">Wah List kamu kosong.<br>
                  Yuk tambahin list kamu  <router-link class="text" :to="{name:'tambah'}">disini</router-link></p>
              </div>
            </div> 
        </div>
    </div>
</div>
</template>
<script>
export default {
  data:function(){
    return{
      Todo:[],
      Error:[],
    }
  },
  DataIndex(){
    axios.get('http://127.0.0.1:8000/todo')
    .then(res => {
      $this.todo = res.data
      console.log(res);
    });
  }

}
</script>