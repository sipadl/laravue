<template>
    <div id="app">
        <div class="se-pre-con"></div>
        <div class="container">
            <div class="pt-4"></div>
            <div class="row">
                <div class="col-md-4">
                    <div v-if="list == 0">
                        <p>Data Kosong</p>
                    </div>
                <div v-else>
                <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="table bg-dark text-light" align="center">
                        <th>No.</th>
                        <th>Nama</th>
                        <th>Judul</th>
                        <th>Opsi</th>
                    </thead>
                    <tbody>
                        <tr v-for="(data, index) in list" :key="data.id">
                            <td>{{ index+1 }}</td>
                            <td>{{ data.nama }}</td>
                            <td>{{ data.judul }}</td>
                            <td>
                                <router-link class="btn btn-primary" :to="{ name:'edit', params: {id: data.id} }" >ubah</router-link>
                                <button class="btn btn-info" @click="deletebro(data.id)">hapus</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
<script>
export default {
    data(){
        return{
            list:[],
            i:1,
        }
    },
    mounted() {
        axios.get('http://127.0.0.1:8000/api/post/index')
        .then(res => {
        this.list = res.data.msg;
        });
    },
    methods:{
        deletebro(id){
            axios.delete(`http://127.0.0.1:8000/api/post/${id}/delete`)
            .then(res => {
                this.$router.push('/');
            });
        }
    }
}
</script>