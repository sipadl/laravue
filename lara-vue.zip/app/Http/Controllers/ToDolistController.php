<?php

namespace App\Http\Controllers;

use App\ToDolist as Todo;
use Illuminate\Http\Request;
use Validator;

class ToDolistController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Todo::get();
        return response()->json($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $list = Todo::query();
        $b = [
            'text' => $request->text,
            'status' => 1,
            'created_at' => time(),
        ];
        $data = $list->create($b);
        return response()->json($data);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ToDolist  $toDolist
     * @return \Illuminate\Http\Response
     */
    public function show(ToDolist $toDolist)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ToDolist  $toDolist
     * @return \Illuminate\Http\Response
     */
    public function edit(ToDolist $toDolist)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ToDolist  $toDolist
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $list = Todo::query();
        $p = [
            'text' => $request->text,
            'status' => 1,
            'updated_at' => time(),
        ];

        $data = $list->find($id)->update($p);
        return response()->json([
            'data'  => $data,
            'msg'   => 'Berhasil Mengubah Data' 
            ]);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ToDolist  $toDolist
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = Todo::delete()->find($id);
        return response()->json([
            'msg' => 'Berhasil Menghapus Data'
        ]);
    }
}
