<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('{any}', function () {
    return view('layout.app');
})->where('any', '.*');


Route::prefix('todo')->group(function () {
    Route::get('','ToDolistController@index');
    Route::post('proses','ToDolistController@store');
    Route::put('{id}/ubah','ToDolistController@update');
    // Route::put('{id}/set','ToDolistController');
    Route::delete('{id}/hapus','ToDolistController@destroy');
});